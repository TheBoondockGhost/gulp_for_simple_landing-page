import * as nodePath from 'path';
const rootFolder = nodePath.basename(nodePath.resolve());

const buildFolder = './dist';
const srcForlder = './src';

export const path = {
    build: {
        html: `${buildFolder}/`,
        css: `${buildFolder}/css/`,
        js: `${buildFolder}/js/`,
        images: `${buildFolder}/img/`,
        fonts: `${buildFolder}/fonts/`,
        files: `${buildFolder}/files/`
    },
    src: {
        html: `${srcForlder}/*.html`,
        scss: `${srcForlder}/scss/style.scss`,
        js: `${srcForlder}/js/app.js`,
        images: `${srcForlder}/img/**/*.{jpg,jpeg,png,gif,webp}`,
        svg: `${srcForlder}/img/**/*.svg`,
        files: `${srcForlder}/files/**/*.*`
    },
    watch: {
        html: `${srcForlder}/**/*.html`,
        scss: `${srcForlder}/scss/**/*.scss`,
        js: `${srcForlder}/js/**/*.js`,
        images: `${srcForlder}/img/**/*.{jpg,jpeg,png,gif,webp}`,
        files: `${srcForlder}/files/**/*.*`
    },
    clean: buildFolder,
    buildFolder: buildFolder,
    srcForlder: srcForlder,
    rootFolder: rootFolder,
    ftp: '',
}