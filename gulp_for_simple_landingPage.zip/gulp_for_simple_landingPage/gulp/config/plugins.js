import browsersync from "browser-sync"; // Локальный сервер
import replace from "gulp-replace"; // Поиск и замена
import gulpPlumber from "gulp-plumber"; // Обработка ошибок
import notify from "gulp-notify"; // Сообщения (подсказки)
import newer from "gulp-newer"; // Проверка обновлений
import ifPlugin from "gulp-if"; // Условное ветвление

export const plugins = {
    replace: replace,
    plumber: gulpPlumber,
    notify: notify,
    browsersync: browsersync,
    newer: newer,
    if: ifPlugin,
}