import * as utilFunctions from "./modules/functions.js";

utilFunctions.testWebP();

  // core version + navigation, pagination modules:
//   import Swiper, { Navigation, Pagination } from 'swiper';